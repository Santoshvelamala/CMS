from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^rend/$', views.rend, name='rend'),
    url(r'^driverlogin/$', views.DriverLogin, name='DriverLogin'),
    url(r'^driverhome/$', views.DriverHome, name='DriverHome'),
    url(r'^driverregister/$', views.DriverRegister, name='DriverRegister'),
]

