from django import forms

class DriverLoginForm(forms.Form):
    Driving_licence_number = forms.CharField(label='Driving Licence Number', max_length=20)
    Password = forms.CharField(label='Password', max_length=20)

class MailForm(forms.Form):
    msg=forms.CharField(label='Your Message',widget=forms.Textarea)

class DriverRegisterForm(forms.Form):
	Password = forms.CharField(label='Password', max_length=20)
	First_name = forms.CharField(label='First_name', max_length=20)
	Last_name = forms.CharField(label='Last_name', max_length=20)
	Birth_date = forms.DateField()
	Driving_licence_number = forms.CharField(label='Driving Licence Number', max_length=20)
	Expiry_date = forms.DateField()
	Working = forms.BooleanField(initial=False,label='Working')
	#Driver_pic = 
