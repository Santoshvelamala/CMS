# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.template import loader
#from .models import Kissan
from django.shortcuts import render
from django.http import HttpResponse
from django.template import RequestContext
from django.shortcuts import render_to_response
import requests
import json
import urllib
from django.http import HttpResponseRedirect
from .forms import DriverLoginForm,DriverRegisterForm
from .forms import MailForm
#from django.utils import simplejson
# Create your views here.
import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
import requests

url = 'http://127.0.0.1:1996/carmodels'
response = urllib.urlopen(url)
data =json.loads(response.read())

def rend(request):
    return render(request,'clientapp/carmodel.html',context={'data':data} )

def DriverHome(request):
	return render(request,'clientapp/home.html',context={'data':data} )

def DriverLogin(request):
	form = DriverLoginForm(request.POST)
        if form.is_valid():
		DLN=form.cleaned_data['Driving_licence_number']
		Pwd=form.cleaned_data['Password']
		payload= {'DLN': DLN, 'Pwd': Pwd}
		response= requests.post('http://localhost:1996/cms/',data=payload)
		if response=="Logged in successfully":
			return render(request,'clientapp/home.html',context={'data':data} )
		else:
			print ("You seem to register First")
	else:
        	form = DriverLoginForm(request.POST)
	return render(request, 'clientapp/contacts.html', {'form': form})

def DriverRegister(request):
	form = DriverRegisterForm(request.POST)
	if form.is_valid():
		payload= {'Password':form.cleaned_data['Password'],'First_name':form.cleaned_data['First_name'],'Last_name':form.cleaned_data['Last_name'],'Birth_date':form.cleaned_data['Birth_date'],'Driving_licence_number':form.cleaned_data['Driving_licence_number'], 'Expiry_date':form.cleaned_data['Expiry_date'], 'Working':form.cleaned_data['Working']}
		response= requests.post('http://localhost:1996/cms/driverregister/',data=payload)
	else:
        	form = DriverRegisterForm(request.POST)
	return render(request, 'clientapp/registerfrom.html', {'form': form})

def Register(request):
	return HttpResponse("HELLO")



